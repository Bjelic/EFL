package service;

import model.DTOEmployee;
import model.EntityEmployee;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ServiceEmployee {

    List<DTOEmployee> findAll();

    DTOEmployee findById(long id);

    DTOEmployee create(DTOEmployee employee);

    DTOEmployee update(DTOEmployee employee);

    void deleteById(long id);

    Long findByAvgSalary(long salary);
}
