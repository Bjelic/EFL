package model;


import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Data
@Entity
@Table(name = "employees")
public class EntityEmployee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank
    @Column(name = "employee_name")
    private String name;
    @NotBlank
    @Column(name = "surname")
    private String surname;
    @NotBlank
    @Column(name = "email")
    private String email;
    @NotBlank
    @Column(name = "address")
    private String address;
    @NotBlank
    @Column(name = "salary")
    private Long salary;
    @Transient
    @OneToMany
    @JoinColumn(name = "company_id")
    private EntityCompany company;
}
