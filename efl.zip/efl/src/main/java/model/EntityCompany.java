package model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "company")
public class EntityCompany {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "company_name")
    private final String name;

    private EntityCompany() {
        name = "BadaBing";
    }
}
