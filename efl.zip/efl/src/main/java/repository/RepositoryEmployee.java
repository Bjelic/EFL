package repository;

import model.EntityEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositoryEmployee extends JpaRepository<EntityEmployee, Long> {

    @Query(value = "SELECT AVG(salary) FROM employees")
    Long findByAvgSalary(long salary);
}
